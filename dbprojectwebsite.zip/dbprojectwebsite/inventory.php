<?php
// Enable CORS (if you're accessing this from another domain or for testing)
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization");
header("Content-Type: application/json"); // Ensure response is JSON

// Database configuration
$host = "localhost";
$username = "root";
$password = "";
$dbname = "flowershopsqldata";

// Connect to the database
$conn = new mysqli($host, $username, $password, $dbname);
if ($conn->connect_error) {
    http_response_code(500); // Internal server error
    echo json_encode(["success" => false, "message" => "Database connection failed"]);
    exit;
}

// Handle only POST requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get raw POST data
    $inputData = file_get_contents('php://input');
    
    // Parse JSON input
    $data = json_decode($inputData, true);

    if (json_last_error() !== JSON_ERROR_NONE) {
        http_response_code(400); // Bad request
        echo json_encode(["success" => false, "message" => "Invalid JSON input"]);
        exit;
    }

    // Validate the action field
    if (isset($data['action']) && $data['action'] === 'adminLogin') {
        // Retrieve email and adminID
        $email = isset($data['email']) ? $data['email'] : '';
        $adminID = isset($data['adminID']) ? $data['adminID'] : '';

        // Example validation for login credentials
        if ($email === 'manager@example.com' && $adminID === '1') {
            // Success response
            echo json_encode(["success" => true, "message" => "Login successful"]);
        } else {
            // Failure response
            http_response_code(401); // Unauthorized
            echo json_encode(["success" => false, "message" => "Invalid email or admin ID"]);
        }
    } else {
        // Handle invalid action
        http_response_code(400); // Bad request
        echo json_encode(["success" => false, "message" => "Invalid action"]);
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    // Handle preflight requests (for CORS)
    http_response_code(204); // No content
} else {
    // Unsupported HTTP methods
    http_response_code(405); // Method not allowed
    echo json_encode(["success" => false, "message" => "Method not allowed"]);
}
?>
